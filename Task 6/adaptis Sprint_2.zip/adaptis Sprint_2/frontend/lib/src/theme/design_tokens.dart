import 'package:flutter/material.dart';

class DT {
  // Colors
  static const primary = Color(0xFF0FA57A);
  static const primaryDark = Color(0xFF066848);
  static const accent = Color(0xFF22C3A0);
  static const surface = Color(0xFFFFFFFF);
  static const background = Color(0xFFF3FBF8);
  static const textPrimary = Color(0xFF0B1A1A);
  static const textSecondary = Color(0xFF657075);
  static const disabled = Color(0xFFE6EEE9);

  // Radii
  static const radiusSmall = 8.0;
  static const radiusMedium = 12.0;
  static const radiusLarge = 16.0;

  // Spacing
  static const spacing = 8.0;

  // Text styles
  static final heading1 = TextStyle(fontFamily: 'Poppins', fontSize: 28, fontWeight: FontWeight.w700, color: textPrimary);
  static final heading2 = TextStyle(fontFamily: 'Poppins', fontSize: 22, fontWeight: FontWeight.w600, color: textPrimary);
  static final body = TextStyle(fontSize: 16, color: textPrimary, height: 1.4);
  static final caption = TextStyle(fontSize: 12, color: textSecondary);
}
