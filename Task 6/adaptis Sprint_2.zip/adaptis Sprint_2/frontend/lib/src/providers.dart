import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'models/user.dart';
import 'services/adaptive_service.dart';
import 'demo/demo_data.dart';
import 'package:hive/hive.dart';

// Simple auth state
class AuthState {
  final bool isAuthenticated;
  final User? user;
  AuthState({this.isAuthenticated = false, this.user});
}

class AuthNotifier extends StateNotifier<AuthState> {
  AuthNotifier(): super(AuthState());

  void loginAs(User user) {
    state = AuthState(isAuthenticated: true, user: user);
  }

  void logout() {
    state = AuthState(isAuthenticated: false, user: null);
  }
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) => AuthNotifier());

// Adaptive learning service provider
final adaptiveServiceProvider = Provider<AdaptiveLearningService>((ref) {
  return AdaptiveLearningService();
});

// Network quality provider (demo manual override)
final networkQualityProvider = StateProvider<ConnectionQuality>((ref) {
  // persist network quality in Hive settings if available
  try {
    final box = Hive.box('settings');
    final saved = box.get('networkQuality');
    if (saved != null) return ConnectionQuality.values[saved as int];
  } catch (e) {
    // ignore
  }
  return ConnectionQuality.GOOD;
});

// Offline mode toggle (simulate no internet)
final offlineModeProvider = StateProvider<bool>((ref) {
  try {
    final box = Hive.box('settings');
    final saved = box.get('offlineMode');
    if (saved != null) return saved as bool;
  } catch (e) {}
  return false;
});

// persist offlineMode changes
final offlineModePersistProvider = Provider<void>((ref) {
  ref.listen<bool>(offlineModeProvider, (prev, next) {
    try { Hive.box('settings').put('offlineMode', next); } catch (e) {}
  });
  return null;
});

// Offline service provider
import 'services/offline_service.dart';

final offlineServiceProvider = Provider<OfflineService>((ref) => OfflineService());

// persist networkQuality changes
final networkQualityPersistProvider = Provider<void>((ref) {
  ref.listen<ConnectionQuality>(networkQualityProvider, (prev, next) {
    try { Hive.box('settings').put('networkQuality', next.index); } catch (e) {}
  });
  return null;
});

// Demo data provider
final demoCoursesProvider = Provider((ref) => DemoData.courses);

// Number of downloaded lessons (stored in Hive 'downloads' box)
final downloadedCountProvider = StateProvider<int>((ref) {
  try {
    final box = Hive.box('downloads');
    return box.keys.length;
  } catch (e) {
    return 0;
  }
});

// Seed frontend Hive with demo data (idempotent)
Future<void> seedFrontendDemo() async {
  try {
    final settings = Hive.box('settings');
    final seeded = settings.get('frontendDemoSeeded') ?? false;
    if (seeded == true) return;

    final offline = OfflineService();
    for (final course in DemoData.courses) {
      for (final lesson in course.lessons) {
        final m = {
          'id': lesson.id,
          'courseId': course.id,
          'courseTitle': course.title,
          'teacherName': course.teacherName,
          'title': lesson.title,
          'textContent': lesson.textContent,
          'audioUrl': lesson.audioUrl,
          'videoUrl': lesson.videoUrl,
        };
        await offline.saveDownloadedLesson(m);
        await offline.saveProgress('progress_${lesson.id}', {'lessonId': lesson.id, 'completed': false, 'position': 0});
      }
    }
    settings.put('frontendDemoSeeded', true);
  } catch (e) {
    // ignore seeding errors in demo mode
  }
}
