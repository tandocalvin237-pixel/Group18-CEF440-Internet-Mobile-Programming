import '../models/course.dart';
import '../models/lesson.dart';

class DemoData {
  static final courses = <Course>[
    Course(
      id: 'c1',
      title: 'Adaptive Learning Basics',
      description: 'Learn how the Adaptis adaptive engine works',
      teacherName: 'Dr. Sarah Jenkins',
      lessons: [
        Lesson(id: 'l1', title: 'Intro', textContent: 'Welcome to Adaptis intro text.', audioUrl: null, videoUrl: null),
        Lesson(id: 'l2', title: 'Adaptive Modes', textContent: 'Transcript for adaptive modes...', audioUrl: null, videoUrl: null),
      ],
    ),
    Course(
      id: 'c2',
      title: 'UI/UX Design Fundamentals',
      description: 'Core principles for mobile UI/UX',
      teacherName: 'Prof. Michael Chen',
      lessons: [
        Lesson(id: 'l3', title: 'Design Principles', textContent: 'Design is about people...', audioUrl: null, videoUrl: null),
      ],
    )
  ];
}

