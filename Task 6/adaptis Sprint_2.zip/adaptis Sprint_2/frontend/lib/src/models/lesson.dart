class Lesson {
  final String id;
  final String title;
  final String textContent;
  final String? audioUrl;
  final String? videoUrl;
  Lesson({required this.id, required this.title, required this.textContent, this.audioUrl, this.videoUrl});
}
