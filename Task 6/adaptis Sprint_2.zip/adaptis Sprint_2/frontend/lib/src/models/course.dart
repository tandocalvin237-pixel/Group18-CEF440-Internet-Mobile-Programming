import 'lesson.dart';

class Course {
  final String id;
  final String title;
  final String description;
  final String teacherName;
  final List<Lesson> lessons;
  Course({required this.id, required this.title, required this.description, required this.teacherName, required this.lessons});
}
