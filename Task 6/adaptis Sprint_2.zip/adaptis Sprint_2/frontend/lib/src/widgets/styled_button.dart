import 'package:flutter/material.dart';
import '../theme/design_tokens.dart';

class StyledPrimaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  StyledPrimaryButton({required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: DT.primary,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(DT.radiusMedium)),
        elevation: 2,
        padding: EdgeInsets.symmetric(vertical: 14, horizontal: 20),
      ),
      child: Text(label, style: TextStyle(fontWeight: FontWeight.w600)),
    );
  }
}

class StyledSecondaryButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;
  StyledSecondaryButton({required this.label, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        foregroundColor: DT.primaryDark,
        side: BorderSide(color: DT.primaryDark.withValues(alpha: 0.12)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(DT.radiusMedium)),
        padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      ),
      child: Text(label, style: TextStyle(fontWeight: FontWeight.w500, color: DT.primaryDark)),
    );
  }
}
