import 'package:flutter/material.dart';
import '../theme/design_tokens.dart';

class StyledCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  StyledCard({required this.child, this.padding = const EdgeInsets.all(12)});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: DT.surface,
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(DT.radiusLarge)),
      child: Padding(padding: padding, child: child),
    );
  }
}
