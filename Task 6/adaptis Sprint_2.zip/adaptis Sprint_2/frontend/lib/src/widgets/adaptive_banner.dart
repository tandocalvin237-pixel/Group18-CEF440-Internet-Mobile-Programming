import 'package:flutter/material.dart';

class AdaptiveBanner extends StatelessWidget {
  final String label;
  final Color color;
  AdaptiveBanner({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(12)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.network_check, color: color, size: 16),
        SizedBox(width: 8),
        Text(label, style: TextStyle(color: color, fontWeight: FontWeight.w600))
      ]),
    );
  }
}
