import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/lesson.dart';
import '../providers.dart';
import '../services/adaptive_service.dart';
import '../widgets/styled_card.dart';
import '../widgets/adaptive_banner.dart';
import '../theme/design_tokens.dart';

class LessonViewerPage extends ConsumerWidget {
  final Lesson lesson;
  LessonViewerPage({required this.lesson});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final quality = ref.watch(networkQualityProvider);
    final adaptive = ref.read(adaptiveServiceProvider);
    adaptive.setQuality(ConnectionQuality.values[quality.index]);
    final mode = adaptive.mode;

    Widget child;
    switch (mode) {
      case MediaMode.VIDEO:
        child = Center(child: Icon(Icons.ondemand_video, size: 120, color: Colors.green));
        break;
      case MediaMode.AUDIO:
        child = Center(child: Icon(Icons.audiotrack, size: 120, color: Colors.orange));
        break;
      case MediaMode.TEXT:
      default:
        child = SingleChildScrollView(child: Padding(padding: EdgeInsets.all(12), child: Text(lesson.textContent)));
    }

    final offline = ref.watch(offlineServiceProvider);
    final isDownloaded = offline.isLessonDownloaded(lesson.id);

    return Scaffold(
      appBar: AppBar(title: Text(lesson.title)),
      body: Column(children: [
        Padding(padding: EdgeInsets.all(8), child: AdaptiveBanner(label: adaptive.modeLabel(), color: adaptive.mode == MediaMode.VIDEO ? DT.primary : (adaptive.mode == MediaMode.AUDIO ? Colors.orange : Colors.red))),
        SizedBox(height: 8),
        Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Row(children: [
          Expanded(child: Text(isDownloaded ? 'Available Offline' : 'Online only', style: DT.body)),
          SizedBox(width: 8),
          ElevatedButton.icon(
            onPressed: isDownloaded ? null : () async {
              // simulate download by saving lesson map
              await offline.saveDownloadedLesson({ 'id': lesson.id, 'title': lesson.title, 'textContent': lesson.textContent, 'audioUrl': lesson.audioUrl, 'videoUrl': lesson.videoUrl });
              // force rebuild
              (context as Element).markNeedsBuild();
            },
            icon: Icon(isDownloaded ? Icons.check : Icons.download),
            label: Text(isDownloaded ? 'Downloaded' : 'Download')
          )
        ])),
        SizedBox(height: 8),
        Expanded(child: StyledCard(child: child))
      ]),
    );
  }
}
