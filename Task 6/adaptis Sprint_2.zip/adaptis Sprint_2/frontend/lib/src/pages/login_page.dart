import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers.dart';
import '../models/user.dart';
import '../widgets/styled_button.dart';
import '../widgets/styled_card.dart';
import '../theme/design_tokens.dart';

class LoginPage extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    void demoLogin(String role) {
      final user = User(id: 'demo-$role', name: 'Demo ${role}', email: '$role@demo.local', role: role);
      ref.read(authProvider.notifier).loginAs(user);
    }

    return Scaffold(
      backgroundColor: DT.background,
      body: Center(
        child: SizedBox(
          width: 360,
          child: StyledCard(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              SizedBox(height: 12),
              Text('Adaptis', style: DT.heading1),
              SizedBox(height: 8),
              Text('Demo Login', style: Theme.of(context).textTheme.headlineSmall),
              SizedBox(height: 16),
              StyledPrimaryButton(label: 'Login as Student', onPressed: () => demoLogin('student')),
              SizedBox(height: 8),
              StyledSecondaryButton(label: 'Login as Teacher', onPressed: () => demoLogin('teacher')),
              SizedBox(height: 8),
              StyledSecondaryButton(label: 'Login as Admin', onPressed: () => demoLogin('admin')),
              SizedBox(height: 12),
            ]),
          ),
        ),
      ),
    );
  }
}
