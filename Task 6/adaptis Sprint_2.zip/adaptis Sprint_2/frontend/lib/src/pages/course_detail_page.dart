import 'package:flutter/material.dart';
import '../models/course.dart';
import 'lesson_viewer_page.dart';
import '../widgets/styled_card.dart';
import '../theme/design_tokens.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CourseDetailPage extends StatelessWidget {
  final Course course;
  CourseDetailPage({required this.course});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(course.title)),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(children: [
          StyledCard(child: Text(course.description, style: DT.body)),
          SizedBox(height: 12),
          Expanded(
            child: ListView.builder(
              itemCount: course.lessons.length,
              itemBuilder: (ctx, i) {
                final l = course.lessons[i];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: StyledCard(
                    child: ListTile(
                      leading: SizedBox(width: 56, height: 56, child: ClipRRect(borderRadius: BorderRadius.circular(8), child: SvgPicture.asset(i % 2 == 0 ? 'assets/thumb_design.svg' : 'assets/thumb_cyber.svg', fit: BoxFit.cover))),
                      title: Text(l.title, style: DT.heading2),
                      subtitle: Text(l.textContent.length > 80 ? l.textContent.substring(0,80) + '...' : l.textContent, style: DT.body),
                      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonViewerPage(lesson: l))),
                    ),
                  ),
                );
              },
            ),
          )
        ]),
      ),
    );
  }
}
