import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers.dart';
import '../theme/design_tokens.dart';
import '../widgets/styled_card.dart';
import '../widgets/styled_button.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '../services/adaptive_service.dart';
import 'course_detail_page.dart';
import 'offline_library_page.dart';

class DashboardPage extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final courses = ref.watch(demoCoursesProvider);
    final networkQ = ref.watch(networkQualityProvider);

    return Scaffold(
      appBar: AppBar(title: Text('Adaptis')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Row(children: [
              Text('Network:', style: DT.body),
              SizedBox(width: 8),
              DropdownButton<ConnectionQuality>(
                value: networkQ,
                items: ConnectionQuality.values.map((q) => DropdownMenuItem(value: q, child: Text(q.toString().split('.').last))).toList(),
                onChanged: (v) {
                  if (v != null) ref.read(networkQualityProvider.notifier).state = v;
                },
              ),
              SizedBox(width: 12),
              Consumer(builder: (context, r, _) {
                final offline = r.watch(offlineModeProvider);
                final downloadedCount = r.watch(downloadedCountProvider);
                return Row(children: [
                  Text('Offline', style: DT.body),
                  Switch(value: offline, onChanged: (v) => r.read(offlineModeProvider.notifier).state = v),
                  SizedBox(width: 8),
                  IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => OfflineLibraryPage())), icon: Icon(Icons.download_for_offline)),
                  SizedBox(width: 8),
                  Chip(label: Text('$downloadedCount')),
                  SizedBox(width: 8),
                  IconButton(
                    tooltip: 'Reseed demo data',
                    onPressed: () async {
                      await seedFrontendDemo();
                      // refresh downloaded count
                      final offlineSvc = r.read(offlineServiceProvider);
                      r.read(downloadedCountProvider.notifier).state = offlineSvc.getDownloadedIds().length;
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Demo data reseeded')));
                    },
                    icon: Icon(Icons.refresh),
                  ),
                ]);
              }),
              Spacer(),
              StyledSecondaryButton(label: 'Logout', onPressed: () => ref.read(authProvider.notifier).logout())
            ]),
            SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: courses.length,
                itemBuilder: (context, idx) {
                  final c = courses[idx];
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: StyledCard(
                      child: ListTile(
                        leading: SizedBox(width: 72, height: 56, child: ClipRRect(borderRadius: BorderRadius.circular(8), child: SvgPicture.asset(idx % 2 == 0 ? 'assets/thumb_design.svg' : 'assets/thumb_cyber.svg', fit: BoxFit.cover))),
                        title: Text(c.title, style: DT.heading2),
                        subtitle: Text('${c.teacherName} • ${c.description}', style: DT.caption),
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CourseDetailPage(course: c))),
                      ),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
