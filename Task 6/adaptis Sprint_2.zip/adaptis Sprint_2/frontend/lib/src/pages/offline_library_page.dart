import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/offline_service.dart';
import '../providers.dart';
import '../theme/design_tokens.dart';
import '../widgets/styled_card.dart';
import '../models/lesson.dart';
import 'lesson_viewer_page.dart';

class OfflineLibraryPage extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final offline = ref.read(offlineServiceProvider);
    final keys = offline.getDownloadedIds();
    return Scaffold(
      appBar: AppBar(title: Text('Offline Library')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: keys.isEmpty
            ? Center(child: Text('No downloaded lessons', style: DT.body))
            : ListView.builder(
                itemCount: keys.length,
                itemBuilder: (ctx, i) {
                  final id = keys[i];
                  final data = offline.getDownloadedLesson(id)!;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: StyledCard(
                      child: ListTile(
                        title: Text(data['title'] ?? 'Lesson', style: DT.heading2),
                        subtitle: Text((data['textContent'] ?? '').toString().substring(0, (data['textContent'] ?? '').toString().length>80?80:(data['textContent'] ?? '').toString().length), style: DT.body),
                        onTap: () {
                          final lesson = Lesson(id: id, title: data['title'] ?? 'Lesson', textContent: data['textContent'] ?? '', audioUrl: data['audioUrl'], videoUrl: data['videoUrl']);
                          Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonViewerPage(lesson: lesson)));
                        },
                      ),
                    ),
                  );
                }),
      ),
    );
  }
}
