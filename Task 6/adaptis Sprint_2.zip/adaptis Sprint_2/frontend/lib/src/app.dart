import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'pages/login_page.dart';
import 'pages/dashboard_page.dart';
import 'providers.dart';
import 'theme/design_tokens.dart';


class AdaptisApp extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final colorScheme = ColorScheme.light(
      primary: DT.primary,
      onPrimary: Colors.white,
      secondary: DT.accent,
      surface: DT.surface,
      onSurface: DT.textPrimary,
    );

    final theme = ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: DT.background,
      appBarTheme: AppBarTheme(backgroundColor: DT.surface, elevation: 0, iconTheme: IconThemeData(color: DT.primaryDark), titleTextStyle: DT.heading2),
      textTheme: TextTheme(bodyLarge: DT.body, bodyMedium: DT.body, bodySmall: DT.caption, headlineSmall: DT.heading2),
      elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(backgroundColor: DT.primary, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(DT.radiusMedium)), padding: EdgeInsets.symmetric(vertical: 14, horizontal: 20))),
    );
    final auth = ref.watch(authProvider);
    return MaterialApp(
      title: 'Adaptis',
      theme: theme,
      home: auth.isAuthenticated ? DashboardPage() : LoginPage(),
    );
  }
}
