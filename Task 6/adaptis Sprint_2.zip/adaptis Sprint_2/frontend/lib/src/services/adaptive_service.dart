enum ConnectionQuality { GOOD, FAIR, POOR }

enum MediaMode { VIDEO, AUDIO, TEXT }

class AdaptiveLearningService {
  ConnectionQuality _quality = ConnectionQuality.GOOD;

  ConnectionQuality get quality => _quality;

  void setQuality(ConnectionQuality q) {
    _quality = q;
  }

  MediaMode get mode {
    switch (_quality) {
      case ConnectionQuality.GOOD:
        return MediaMode.VIDEO;
      case ConnectionQuality.FAIR:
        return MediaMode.AUDIO;
      case ConnectionQuality.POOR:
      default:
        return MediaMode.TEXT;
    }
  }

  String modeLabel() {
    final m = mode;
    switch (m) {
      case MediaMode.VIDEO:
        return 'Video';
      case MediaMode.AUDIO:
        return 'Audio';
      case MediaMode.TEXT:
      default:
        return 'Text';
    }
  }
}
