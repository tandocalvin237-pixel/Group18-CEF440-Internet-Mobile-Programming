import 'package:hive/hive.dart';

class OfflineService {
  final Box _downloads = Hive.box('downloads');
  final Box _progress = Hive.box('progress');
  final Box _settings = Hive.box('settings');

  Future<void> saveDownloadedLesson(Map<String, dynamic> lesson) async {
    // store by lesson id
    final id = lesson['id'];
    await _downloads.put(id, lesson);
  }

  bool isLessonDownloaded(String lessonId) {
    return _downloads.containsKey(lessonId);
  }

  Map<String, dynamic>? getDownloadedLesson(String lessonId) {
    return _downloads.get(lessonId) as Map<String, dynamic>?;
  }

  List<String> getDownloadedIds() {
    try {
      return _downloads.keys.cast<String>().toList();
    } catch (e) {
      return [];
    }
  }

  List<Map<String, dynamic>> listDownloadedLessons() {
    try {
      return _downloads.values.map((v) => Map<String, dynamic>.from(v as Map)).toList();
    } catch (e) {
      return [];
    }
  }

  Future<void> saveProgress(String key, Map<String, dynamic> data) async {
    await _progress.put(key, data);
  }

  Map<String, dynamic>? getProgress(String key) {
    return _progress.get(key) as Map<String, dynamic>?;
  }

  // settings
  void setSetting(String key, dynamic value) => _settings.put(key, value);
  dynamic getSetting(String key) => _settings.get(key);
}
