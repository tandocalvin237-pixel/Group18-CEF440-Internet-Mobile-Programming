import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'src/app.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'src/providers.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  // open boxes used by the app
  await Hive.openBox('downloads');
  await Hive.openBox('progress');
  await Hive.openBox('settings');

  // seed demo data into Hive for offline demo mode
  await seedFrontendDemo();

  runApp(ProviderScope(child: AdaptisApp()));
}
