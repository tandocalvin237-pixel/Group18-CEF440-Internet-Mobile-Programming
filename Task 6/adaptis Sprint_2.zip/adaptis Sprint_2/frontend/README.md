# Adaptis Frontend (Flutter MVP)

This is a minimal Flutter frontend scaffold for the Adaptis MVP.

To run:

```bash
cd frontend
flutter pub get
flutter run
```

Notes:
- The app uses `flutter_riverpod` for state management, `hive` for local storage, and `connectivity_plus` for network quality detection.
- For demo mode the app includes a manual network-quality toggle.
