const Message = require('../models/message.model');

async function sendMessage(req, res) {
  try {
    const from = req.user.id;
    const { to, text, courseId } = req.body;
    if (!to || !text) return res.status(400).json({ success: false, error: 'Missing fields' });
    const m = await Message.create({ from, to, text, courseId });
    res.json({ success: true, data: m });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

async function listConversation(req, res) {
  try {
    const me = req.user.id;
    const other = req.query.with;
    if (!other) return res.status(400).json({ success: false, error: 'Missing conversation partner (with)' });
    const items = await Message.find({ $or: [ { from: me, to: other }, { from: other, to: me } ] }).sort({ createdAt: 1 });
    res.json({ success: true, data: items });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

module.exports = { sendMessage, listConversation };
