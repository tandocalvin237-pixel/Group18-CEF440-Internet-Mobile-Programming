const Progress = require('../models/progress.model');

async function getProgress(req, res) {
  const studentId = req.query.studentId || req.user.id;
  const courseId = req.query.courseId;
  const filter = { studentId };
  if (courseId) filter.courseId = courseId;
  const items = await Progress.find(filter).sort({ lastAccessed: -1 }).limit(200);
  res.json({ success: true, data: items });
}

async function upsertProgress(req, res) {
  try {
    const { studentId } = req.body;
    const sid = studentId || req.user.id;
    const { courseId, lessonId, percent, mode, networkQuality } = req.body;
    if (!courseId || !lessonId) return res.status(400).json({ success: false, error: 'Missing courseId or lessonId' });
    let p = await Progress.findOne({ studentId: sid, courseId, lessonId });
    const entry = { percent: percent || 0, lastAccessed: new Date() };
    if (p) {
      p.percent = entry.percent;
      p.lastAccessed = entry.lastAccessed;
      if (mode || networkQuality) p.modeHistory = p.modeHistory || [];
      if (mode || networkQuality) p.modeHistory.push({ date: new Date(), mode, networkQuality });
      await p.save();
    } else {
      p = await Progress.create({ studentId: sid, courseId, lessonId, percent: entry.percent, lastAccessed: entry.lastAccessed, modeHistory: mode || networkQuality ? [{ date: new Date(), mode, networkQuality }] : [] });
    }
    res.json({ success: true, data: p });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

module.exports = { getProgress, upsertProgress };
