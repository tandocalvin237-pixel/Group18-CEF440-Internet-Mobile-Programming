const Course = require('../models/course.model');

async function listCourses(req, res) {
  const q = req.query.q || '';
  const page = parseInt(req.query.page || '1', 10);
  const limit = parseInt(req.query.limit || '20', 10);
  const filter = q ? { $text: { $search: q } } : {};
  const items = await Course.find(filter).skip((page-1)*limit).limit(limit).populate('teacher','name email');
  res.json({ success: true, data: items });
}

async function getCourse(req, res) {
  const id = req.params.id;
  const course = await Course.findById(id).populate('teacher','name email');
  if (!course) return res.status(404).json({ success: false, error: 'Not found' });
  res.json({ success: true, data: course });
}

async function createCourse(req, res) {
  const body = req.body;
  const user = req.user;
  if (!user) return res.status(401).json({ success: false, error: 'Unauthorized' });
  try {
    const course = await Course.create({ ...body, teacher: user.id });
    res.json({ success: true, data: course });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

module.exports = { listCourses, getCourse, createCourse };
