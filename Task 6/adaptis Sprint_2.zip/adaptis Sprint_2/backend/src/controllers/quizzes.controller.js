const Quiz = require('../models/quiz.model');
const Question = require('../models/question.model');

async function listQuizzes(req, res) {
  const courseId = req.query.courseId;
  const filter = {};
  if (courseId) filter.courseId = courseId;
  const items = await Quiz.find(filter).limit(100).populate('createdBy','name email');
  res.json({ success: true, data: items });
}

async function getQuiz(req, res) {
  const id = req.params.id;
  const quiz = await Quiz.findById(id).populate('questions');
  if (!quiz) return res.status(404).json({ success: false, error: 'Not found' });
  res.json({ success: true, data: quiz });
}

async function createQuiz(req, res) {
  try {
    const body = req.body;
    body.createdBy = req.user.id;
    // If questions are embedded, create them first
    let questionIds = [];
    if (Array.isArray(body.questions) && body.questions.length) {
      for (const q of body.questions) {
        const created = await Question.create(q);
        questionIds.push(created._id);
      }
    }
    const quiz = await Quiz.create({ ...body, questions: questionIds });
    res.json({ success: true, data: quiz });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

async function submitQuiz(req, res) {
  try {
    const id = req.params.id;
    const answers = req.body.answers || []; // [{ questionId, answer }]
    const quiz = await Quiz.findById(id).populate('questions');
    if (!quiz) return res.status(404).json({ success: false, error: 'Quiz not found' });
    // compute score
    let total = 0;
    let earned = 0;
    const details = [];
    for (const qId of quiz.questions) {
      total += qId.points || 1;
      const provided = answers.find(a => String(a.questionId) === String(qId._id));
      let correct = false;
      if (qId.type === 'mcq') {
        // assume single correct choice marked in Question.choices.correct
        const correctChoice = (qId.choices || []).find(c => c.correct);
        if (provided && correctChoice && provided.answer === correctChoice.id) correct = true;
      } else if (qId.type === 'tf') {
        const correctChoice = (qId.choices || []).find(c => c.correct);
        if (provided && correctChoice && String(provided.answer) === String(correctChoice.id)) correct = true;
      } else {
        // short answer: skip strict matching, mark as 0 for demo
        correct = false;
      }
      if (correct) earned += qId.points || 1;
      details.push({ questionId: qId._id, correct });
    }
    const score = { earned, total, percent: total ? Math.round((earned/total)*100) : 0 };
    res.json({ success: true, data: { score, details } });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

module.exports = { listQuizzes, getQuiz, createQuiz, submitQuiz };
