const Lesson = require('../models/lesson.model');

async function listLessons(req, res) {
  const courseId = req.query.courseId;
  const filter = {};
  if (courseId) filter.courseId = courseId;
  const items = await Lesson.find(filter).sort({ order: 1 }).limit(100);
  res.json({ success: true, data: items });
}

async function getLesson(req, res) {
  const id = req.params.id;
  const lesson = await Lesson.findById(id);
  if (!lesson) return res.status(404).json({ success: false, error: 'Not found' });
  res.json({ success: true, data: lesson });
}

async function createLesson(req, res) {
  try {
    const body = req.body;
    const lesson = await Lesson.create(body);
    res.json({ success: true, data: lesson });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

async function updateLesson(req, res) {
  try {
    const id = req.params.id;
    const body = req.body;
    const updated = await Lesson.findByIdAndUpdate(id, body, { new: true });
    if (!updated) return res.status(404).json({ success: false, error: 'Not found' });
    res.json({ success: true, data: updated });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

async function deleteLesson(req, res) {
  try {
    const id = req.params.id;
    await Lesson.findByIdAndDelete(id);
    res.json({ success: true });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

module.exports = { listLessons, getLesson, createLesson, updateLesson, deleteLesson };
