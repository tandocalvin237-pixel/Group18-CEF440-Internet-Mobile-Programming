const Assignment = require('../models/assignment.model');
const Submission = require('../models/submission.model');

async function listAssignments(req, res) {
  const courseId = req.query.courseId;
  const filter = {};
  if (courseId) filter.courseId = courseId;
  const items = await Assignment.find(filter).sort({ dueDate: 1 }).limit(100);
  res.json({ success: true, data: items });
}

async function getAssignment(req, res) {
  const id = req.params.id;
  const item = await Assignment.findById(id);
  if (!item) return res.status(404).json({ success: false, error: 'Not found' });
  res.json({ success: true, data: item });
}

async function createAssignment(req, res) {
  try {
    const body = req.body;
    body.createdBy = req.user.id;
    const a = await Assignment.create(body);
    res.json({ success: true, data: a });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

async function submitAssignment(req, res) {
  try {
    const assignmentId = req.params.id;
    const studentId = req.user.id;
    const payload = req.body;
    const sub = await Submission.create({ assignmentId, studentId, content: payload });
    res.json({ success: true, data: sub });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

async function listSubmissions(req, res) {
  try {
    const assignmentId = req.params.id;
    const items = await Submission.find({ assignmentId }).populate('studentId','name email');
    res.json({ success: true, data: items });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

module.exports = { listAssignments, getAssignment, createAssignment, submitAssignment, listSubmissions };
