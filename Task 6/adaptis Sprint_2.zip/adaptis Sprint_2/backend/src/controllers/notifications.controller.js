const Notification = require('../models/notification.model');

async function listNotifications(req, res) {
  try {
    const userId = req.user.id;
    const items = await Notification.find({ userId }).sort({ createdAt: -1 }).limit(200);
    res.json({ success: true, data: items });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

async function createNotification(req, res) {
  try {
    const { userId, type, title, body, meta } = req.body;
    if (!userId || !title) return res.status(400).json({ success: false, error: 'Missing fields' });
    const n = await Notification.create({ userId, type, title, body, meta });
    res.json({ success: true, data: n });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

async function markRead(req, res) {
  try {
    const id = req.params.id;
    const updated = await Notification.findByIdAndUpdate(id, { read: true }, { new: true });
    res.json({ success: true, data: updated });
  } catch (err) { console.error(err); res.status(500).json({ success: false, error: 'Server error' }); }
}

module.exports = { listNotifications, createNotification, markRead };
