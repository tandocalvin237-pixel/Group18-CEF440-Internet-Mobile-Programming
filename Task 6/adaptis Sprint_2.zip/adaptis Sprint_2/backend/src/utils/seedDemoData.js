require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('../models/user.model');
const Course = require('../models/course.model');
const Module = require('../models/module.model');
const Lesson = require('../models/lesson.model');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/adaptis_demo';

async function seed() {
  await mongoose.connect(MONGO, { useNewUrlParser: true, useUnifiedTopology: true });
  console.log('Connected to', MONGO);

  // Clear minimal collections
  await User.deleteMany({});
  await Course.deleteMany({});
  await Module.deleteMany({});
  await Lesson.deleteMany({});

  const pwd = await bcrypt.hash('demo123', 10);
  const student = await User.create({ name: 'Demo Student', email: 'student@demo.local', passwordHash: pwd, role: 'student', meta: { demo: true } });
  const teacher = await User.create({ name: 'Demo Teacher', email: 'teacher@demo.local', passwordHash: pwd, role: 'teacher', meta: { demo: true } });
  const admin = await User.create({ name: 'Demo Admin', email: 'admin@demo.local', passwordHash: pwd, role: 'admin', meta: { demo: true } });

  const course = await Course.create({ title: 'UI/UX Design Fundamentals', description: 'Intro to UI/UX for mobile apps', teacher: teacher._id, category: 'Design', tags: ['design','ux','ui'] });

  const mod1 = await Module.create({ courseId: course._id, title: 'Basics', order: 1 });
  const mod2 = await Module.create({ courseId: course._id, title: 'Advanced', order: 2 });
  course.modules = [mod1._id, mod2._id];
  await course.save();

  const lesson1 = await Lesson.create({ moduleId: mod1._id, courseId: course._id, title: 'Adaptive Learning Intro', description: 'Text + audio + video demo', order: 1, assets: { videoUrl: 'https://sample-videos.com/video123/mp4/240/big_buck_bunny_240p_1mb.mp4', audioUrl: 'https://sample-videos.com/audio/mp3/wave.mp3', textContent: 'This is the lesson transcript for Adaptive Learning Intro.' }, downloadable: true });
  const lesson2 = await Lesson.create({ moduleId: mod1._id, courseId: course._id, title: 'Design Principles', description: 'Core design principles', order: 2, assets: { textContent: 'Design is...' }, downloadable: true });

  mod1.lessons = [lesson1._id, lesson2._id];
  await mod1.save();

  console.log('Seeding complete: users and one course created');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
