module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'change_this_for_demo'
};
