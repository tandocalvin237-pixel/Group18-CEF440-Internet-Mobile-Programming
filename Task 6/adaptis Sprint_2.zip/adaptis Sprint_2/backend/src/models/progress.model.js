const mongoose = require('mongoose');

const ModeHistorySchema = new mongoose.Schema({
  date: { type: Date, default: Date.now },
  mode: { type: String, enum: ['VIDEO','AUDIO','TEXT'] },
  networkQuality: { type: String, enum: ['GOOD','FAIR','POOR'] }
}, { _id: false });

const ProgressSchema = new mongoose.Schema({
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', index: true },
  lessonId: { type: mongoose.Schema.Types.ObjectId, ref: 'Lesson' },
  percent: { type: Number, default: 0 },
  lastAccessed: { type: Date, default: Date.now },
  modeHistory: [ModeHistorySchema]
}, { timestamps: true });

ProgressSchema.index({ studentId: 1, courseId: 1 });

module.exports = mongoose.model('Progress', ProgressSchema);
