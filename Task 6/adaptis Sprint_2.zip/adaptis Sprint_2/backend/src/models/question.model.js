const mongoose = require('mongoose');

const ChoiceSchema = new mongoose.Schema({
  id: { type: String },
  text: { type: String },
  correct: { type: Boolean, default: false }
}, { _id: false });

const QuestionSchema = new mongoose.Schema({
  quizId: { type: mongoose.Schema.Types.ObjectId, ref: 'Quiz', index: true },
  text: { type: String, required: true },
  type: { type: String, enum: ['mcq','tf','short'], default: 'mcq' },
  choices: [ChoiceSchema],
  points: { type: Number, default: 1 }
}, { timestamps: true });

QuestionSchema.index({ quizId: 1 });

module.exports = mongoose.model('Question', QuestionSchema);
