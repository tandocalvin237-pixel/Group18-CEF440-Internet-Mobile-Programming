const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  description: { type: String },
  teacher: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  category: { type: String },
  coverImageUrl: { type: String },
  tags: [{ type: String }],
  modules: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Module' }],
  published: { type: Boolean, default: true }
}, { timestamps: true });

CourseSchema.index({ title: 'text', description: 'text' });

module.exports = mongoose.model('Course', CourseSchema);
