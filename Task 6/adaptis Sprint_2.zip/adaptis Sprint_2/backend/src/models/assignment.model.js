const mongoose = require('mongoose');

const AssignmentSchema = new mongoose.Schema({
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', index: true },
  moduleId: { type: mongoose.Schema.Types.ObjectId, ref: 'Module' },
  title: { type: String, required: true },
  description: { type: String },
  dueDate: { type: Date },
  points: { type: Number, default: 0 },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }
}, { timestamps: true });

AssignmentSchema.index({ courseId: 1, dueDate: 1 });

module.exports = mongoose.model('Assignment', AssignmentSchema);
