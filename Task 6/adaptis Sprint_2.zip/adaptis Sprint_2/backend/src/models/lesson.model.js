const mongoose = require('mongoose');

const AssetSchema = new mongoose.Schema({
  videoUrl: { type: String },
  audioUrl: { type: String },
  textContent: { type: String },
  attachments: [{ type: String }]
}, { _id: false });

const LessonSchema = new mongoose.Schema({
  moduleId: { type: mongoose.Schema.Types.ObjectId, ref: 'Module', index: true },
  courseId: { type: mongoose.Schema.Types.ObjectId, ref: 'Course', index: true },
  title: { type: String, required: true },
  description: { type: String },
  order: { type: Number, default: 0 },
  durationSec: { type: Number, default: 0 },
  assets: { type: AssetSchema, default: {} },
  downloadable: { type: Boolean, default: false },
  sizeBytes: { type: Number, default: 0 }
}, { timestamps: true });

LessonSchema.index({ courseId: 1, order: 1 });

module.exports = mongoose.model('Lesson', LessonSchema);
