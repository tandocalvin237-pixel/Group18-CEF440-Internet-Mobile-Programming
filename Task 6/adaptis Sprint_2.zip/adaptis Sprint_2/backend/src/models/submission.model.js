const mongoose = require('mongoose');

const SubmissionSchema = new mongoose.Schema({
  assignmentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Assignment', required: true, index: true },
  studentId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  content: {
    text: { type: String },
    files: [{ type: String }]
  },
  submittedAt: { type: Date, default: Date.now },
  grade: {
    score: { type: Number },
    feedback: { type: String },
    gradedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    gradedAt: { type: Date }
  },
  status: { type: String, enum: ['submitted','graded','late'], default: 'submitted' }
}, { timestamps: true });

SubmissionSchema.index({ assignmentId: 1, studentId: 1 });

module.exports = mongoose.model('Submission', SubmissionSchema);
