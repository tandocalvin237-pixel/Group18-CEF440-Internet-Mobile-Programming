const express = require('express');
const router = express.Router();
const messages = require('../controllers/messages.controller');
const auth = require('../middlewares/auth.middleware');

router.post('/', auth.requireAuth, messages.sendMessage);
router.get('/', auth.requireAuth, messages.listConversation);

module.exports = router;
