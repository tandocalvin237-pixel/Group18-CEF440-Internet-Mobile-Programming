const express = require('express');
const router = express.Router();
const notifications = require('../controllers/notifications.controller');
const auth = require('../middlewares/auth.middleware');
const { requireRole } = require('../middlewares/role.middleware');

router.get('/', auth.requireAuth, notifications.listNotifications);
router.post('/', auth.requireAuth, requireRole(['teacher','admin']), notifications.createNotification);
router.post('/:id/read', auth.requireAuth, notifications.markRead);

module.exports = router;
