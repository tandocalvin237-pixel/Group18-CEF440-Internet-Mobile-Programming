const express = require('express');
const router = express.Router();
const assignments = require('../controllers/assignments.controller');
const auth = require('../middlewares/auth.middleware');
const { requireRole } = require('../middlewares/role.middleware');

router.get('/', assignments.listAssignments);
router.get('/:id', assignments.getAssignment);
router.post('/', auth.requireAuth, requireRole(['teacher','admin']), assignments.createAssignment);
router.post('/:id/submit', auth.requireAuth, requireRole(['student']), assignments.submitAssignment);
router.get('/:id/submissions', auth.requireAuth, requireRole(['teacher','admin']), assignments.listSubmissions);

module.exports = router;
