const express = require('express');
const router = express.Router();
const courses = require('../controllers/courses.controller');
const auth = require('../middlewares/auth.middleware');
const { requireRole } = require('../middlewares/role.middleware');

router.get('/', courses.listCourses);
router.get('/:id', courses.getCourse);
router.post('/', auth.requireAuth, requireRole(['teacher','admin']), courses.createCourse);
// For MVP, allow teachers and admins to update/delete
router.put('/:id', auth.requireAuth, requireRole(['teacher','admin']), async (req, res) => {
  try {
    const id = req.params.id;
    const body = req.body;
    const updated = await require('../models/course.model').findByIdAndUpdate(id, body, { new: true });
    if (!updated) return res.status(404).json({ success: false, error: 'Not found' });
    res.json({ success: true, data: updated });
  } catch (err) { next(err); }
});

router.delete('/:id', auth.requireAuth, requireRole(['teacher','admin']), async (req, res, next) => {
  try {
    const id = req.params.id;
    await require('../models/course.model').findByIdAndDelete(id);
    res.json({ success: true });
  } catch (err) { next(err); }
});

module.exports = router;
const express = require('express');
const router = express.Router();
const coursesCtrl = require('../controllers/courses.controller');
const auth = require('../middlewares/auth.middleware');

router.get('/', coursesCtrl.listCourses);
router.get('/:id', coursesCtrl.getCourse);
router.post('/', auth.requireAuth, coursesCtrl.createCourse);

module.exports = router;
