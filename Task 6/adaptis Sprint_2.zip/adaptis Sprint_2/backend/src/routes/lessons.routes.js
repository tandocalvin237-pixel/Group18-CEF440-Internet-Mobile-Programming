const express = require('express');
const router = express.Router();
const lessons = require('../controllers/lessons.controller');
const auth = require('../middlewares/auth.middleware');
const { requireRole } = require('../middlewares/role.middleware');

router.get('/', lessons.listLessons);
router.get('/:id', lessons.getLesson);
router.post('/', auth.requireAuth, requireRole(['teacher','admin']), lessons.createLesson);
router.put('/:id', auth.requireAuth, requireRole(['teacher','admin']), lessons.updateLesson);
router.delete('/:id', auth.requireAuth, requireRole(['teacher','admin']), lessons.deleteLesson);

module.exports = router;
