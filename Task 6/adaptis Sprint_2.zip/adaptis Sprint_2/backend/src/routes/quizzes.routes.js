const express = require('express');
const router = express.Router();
const quizzes = require('../controllers/quizzes.controller');
const auth = require('../middlewares/auth.middleware');
const { requireRole } = require('../middlewares/role.middleware');

router.get('/', quizzes.listQuizzes);
router.get('/:id', quizzes.getQuiz);
router.post('/', auth.requireAuth, requireRole(['teacher','admin']), quizzes.createQuiz);
router.post('/:id/submit', auth.requireAuth, requireRole(['student']), quizzes.submitQuiz);

module.exports = router;
