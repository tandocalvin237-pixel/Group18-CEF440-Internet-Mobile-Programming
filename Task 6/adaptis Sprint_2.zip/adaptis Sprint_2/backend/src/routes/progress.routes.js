const express = require('express');
const router = express.Router();
const progress = require('../controllers/progress.controller');
const auth = require('../middlewares/auth.middleware');

router.get('/', auth.requireAuth, progress.getProgress);
router.post('/', auth.requireAuth, progress.upsertProgress);

module.exports = router;
