const express = require('express');
const router = express.Router();
const authRoutes = require('./auth.routes');
const coursesRoutes = require('./courses.routes');
const lessonsRoutes = require('./lessons.routes');
const assignmentsRoutes = require('./assignments.routes');
const messagesRoutes = require('./messages.routes');
const progressRoutes = require('./progress.routes');
const quizzesRoutes = require('./quizzes.routes');
const notificationsRoutes = require('./notifications.routes');

router.use('/auth', authRoutes);
router.use('/courses', coursesRoutes);
router.use('/lessons', lessonsRoutes);
router.use('/assignments', assignmentsRoutes);
router.use('/messages', messagesRoutes);
router.use('/progress', progressRoutes);
router.use('/quizzes', quizzesRoutes);
router.use('/notifications', notificationsRoutes);

module.exports = router;
