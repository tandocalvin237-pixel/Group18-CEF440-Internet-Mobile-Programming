function requireBody(fields) {
  return function (req, res, next) {
    const missing = [];
    for (const f of fields) if (req.body[f] === undefined) missing.push(f);
    if (missing.length) return res.status(400).json({ success: false, error: `Missing fields: ${missing.join(',')}` });
    next();
  };
}

module.exports = { requireBody };
