const jwt = require('jsonwebtoken');
const { jwtSecret } = require('../config');

function requireAuth(req, res, next) {
  const h = req.headers.authorization;
  if (!h) return res.status(401).json({ success: false, error: 'Missing Authorization' });
  const parts = h.split(' ');
  if (parts.length !== 2) return res.status(401).json({ success: false, error: 'Invalid Authorization' });
  const token = parts[1];
  try {
    const payload = jwt.verify(token, jwtSecret);
    req.user = { id: payload.id || payload._id, role: payload.role };
    return next();
  } catch (err) {
    return res.status(401).json({ success: false, error: 'Invalid token' });
  }
}

module.exports = { requireAuth };
