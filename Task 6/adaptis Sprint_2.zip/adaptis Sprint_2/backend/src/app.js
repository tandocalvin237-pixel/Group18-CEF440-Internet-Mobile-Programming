const express = require('express');
const cors = require('cors');
const routes = require('./routes');
const { errorHandler } = require('./middlewares/error.middleware');
const logger = require('./utils/logger');

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

app.use((req, res, next) => {
	logger.info(`${req.method} ${req.path}`);
	next();
});

app.use('/api', routes);

app.get('/', (req,res) => res.json({ success: true, message: 'Adaptis backend running' }));

// error handler (last middleware)
app.use(errorHandler);

module.exports = app;
