# Adaptis Backend (MVP)

Small Express + Mongoose backend for the Adaptis demo MVP.

Quick start:

1. Install dependencies:

```bash
cd backend
npm install
```

2. Configure environment: copy `.env.example` to `.env` and adjust `MONGO_URI`.

3. Seed demo data (optional):

```bash
npm run seed
```

4. Run:

```bash
npm run dev
```
