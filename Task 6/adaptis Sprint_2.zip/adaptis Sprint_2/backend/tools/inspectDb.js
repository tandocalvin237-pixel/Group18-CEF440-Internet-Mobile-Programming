#!/usr/bin/env node
require('dotenv').config();
const mongoose = require('mongoose');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/adaptis_demo';

async function inspect() {
  try {
    await mongoose.connect(MONGO, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to', MONGO);

    const db = mongoose.connection.db;
    const cols = await db.listCollections().toArray();
    if (!cols.length) {
      console.log('No collections found in database.');
    }

    for (const c of cols) {
      const name = c.name;
      const coll = db.collection(name);
      const count = await coll.countDocuments();
      console.log(`\nCollection: ${name} (count: ${count})`);
      const docs = await coll.find({}).limit(5).toArray();
      if (docs.length === 0) {
        console.log('  (no sample documents)');
      } else {
        docs.forEach((d, i) => {
          // hide potentially large fields
          if (d.passwordHash) d.passwordHash = '<hidden>'; 
          console.log('  doc', i + 1, JSON.stringify(d, null, 2));
        });
      }
    }

    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error('Error connecting or inspecting DB:', err.message || err);
    process.exit(2);
  }
}

inspect();
